/* USER CODE BEGIN Header */
/**
  ******************************************************************************
  * @file    can.c
  * @brief   This file provides code for the configuration
  *          of the CAN instances.
  ******************************************************************************
  * @attention
  *
  * Copyright (c) 2025 STMicroelectronics.
  * All rights reserved.
  *
  * This software is licensed under terms that can be found in the LICENSE file
  * in the root directory of this software component.
  * If no LICENSE file comes with this software, it is provided AS-IS.
  *
  ******************************************************************************
  */
/* USER CODE END Header */
/* Includes ------------------------------------------------------------------*/
#include "can.h"

/* USER CODE BEGIN 0 */
#include <mte100.h>

/* USER CODE END 0 */

CAN_HandleTypeDef hcan1;

/* CAN1 init function */
void MX_CAN1_Init(void)
{

  /* USER CODE BEGIN CAN1_Init 0 */

  /* USER CODE END CAN1_Init 0 */

  /* USER CODE BEGIN CAN1_Init 1 */

  /* USER CODE END CAN1_Init 1 */
  hcan1.Instance = CAN1;
  hcan1.Init.Prescaler = 6;
  hcan1.Init.Mode = CAN_MODE_NORMAL;
  hcan1.Init.SyncJumpWidth = CAN_SJW_1TQ;
  hcan1.Init.TimeSeg1 = CAN_BS1_2TQ;
  hcan1.Init.TimeSeg2 = CAN_BS2_6TQ;
  hcan1.Init.TimeTriggeredMode = DISABLE;
  hcan1.Init.AutoBusOff = DISABLE;
  hcan1.Init.AutoWakeUp = DISABLE;
  hcan1.Init.AutoRetransmission = DISABLE;
  hcan1.Init.ReceiveFifoLocked = DISABLE;
  hcan1.Init.TransmitFifoPriority = DISABLE;
  if (HAL_CAN_Init(&hcan1) != HAL_OK)
  {
    Error_Handler();
  }
  /* USER CODE BEGIN CAN1_Init 2 */

  /* USER CODE END CAN1_Init 2 */

}

void HAL_CAN_MspInit(CAN_HandleTypeDef* canHandle)
{

  GPIO_InitTypeDef GPIO_InitStruct = {0};
  if(canHandle->Instance==CAN1)
  {
  /* USER CODE BEGIN CAN1_MspInit 0 */

  /* USER CODE END CAN1_MspInit 0 */
    /* CAN1 clock enable */
    __HAL_RCC_CAN1_CLK_ENABLE();

    __HAL_RCC_GPIOA_CLK_ENABLE();
    /**CAN1 GPIO Configuration
    PA11     ------> CAN1_RX
    PA12     ------> CAN1_TX
    */
    GPIO_InitStruct.Pin = CAN_RX_Pin|CAN_TX_Pin;
    GPIO_InitStruct.Mode = GPIO_MODE_AF_PP;
    GPIO_InitStruct.Pull = GPIO_NOPULL;
    GPIO_InitStruct.Speed = GPIO_SPEED_FREQ_VERY_HIGH;
    GPIO_InitStruct.Alternate = GPIO_AF9_CAN1;
    HAL_GPIO_Init(GPIOA, &GPIO_InitStruct);

  /* USER CODE BEGIN CAN1_MspInit 1 */

  /* USER CODE END CAN1_MspInit 1 */
  }
}

void HAL_CAN_MspDeInit(CAN_HandleTypeDef* canHandle)
{

  if(canHandle->Instance==CAN1)
  {
  /* USER CODE BEGIN CAN1_MspDeInit 0 */

  /* USER CODE END CAN1_MspDeInit 0 */
    /* Peripheral clock disable */
    __HAL_RCC_CAN1_CLK_DISABLE();

    /**CAN1 GPIO Configuration
    PA11     ------> CAN1_RX
    PA12     ------> CAN1_TX
    */
    HAL_GPIO_DeInit(GPIOA, CAN_RX_Pin|CAN_TX_Pin);

  /* USER CODE BEGIN CAN1_MspDeInit 1 */

  /* USER CODE END CAN1_MspDeInit 1 */
  }
}

/* USER CODE BEGIN 1 */

/*
 * @Função    : can_init
 * @Descrição : Inicializa os parâmetros e variáveis referentes ao protocolo CAN quando houver.
 * @Parâmetros: Não há
 */
void can_init(void)
{

}

/*
 * @Função    : can_reception
 * @Descrição : Recebe e processa os dados recebidos via protocolo CAN.
 * @Parâmetros: Não há
 */
void can_reception(void)
{
	mte100.data.altura       = ((payload_id_can_0x100[0] << 8) | payload_id_can_0x100[1]);
	mte100.data.peso		 = ((payload_id_can_0x100[2] << 8) | payload_id_can_0x100[3]);
	mte100.data.status_flags = payload_id_can_0x100[4];

	mte100.data.tensao       = (uint8_t) (payload_id_can_0x200[0] * 0.5);
	mte100.data.horimetro	 = ((payload_id_can_0x200[4] << 24) | (payload_id_can_0x200[5] << 16) |(payload_id_can_0x200[6] << 8) | payload_id_can_0x200[7]);

}

/*
 * @Função    : can_simulation_transmition
 * @Descrição : Simula a recepção do protocolo CAN selecionando 4 pacotes diferentes disponíveis.
 * @Parâmetros:
 * 		- packet_num: recebe o valor que indica qual pacote deve ser selecionado
 */
void can_simulation_transmition(uint8_t packet_num)
{
	switch (packet_num)
	{
		case 0:
			payload_id_can_0x100[0] = 0x16; // altura_msb
			payload_id_can_0x100[1] = 0x03; // altura_lsb
			payload_id_can_0x100[2] = 0x04; // peso_msb
			payload_id_can_0x100[3] = 0xE9; // peso_lsb
			payload_id_can_0x100[4] = 0x07; // status_flags
			payload_id_can_0x100[5] = 0x00;
			payload_id_can_0x100[6] = 0x00;
			payload_id_can_0x100[7] = 0x00;

			payload_id_can_0x200[0] = 0x60; // tensao
			payload_id_can_0x200[1]	= 0x00;
			payload_id_can_0x200[2] = 0x00;
			payload_id_can_0x200[3] = 0x00;
			payload_id_can_0x200[4] = 0x00; // horimetro 3 msb
			payload_id_can_0x200[5] = 0x00; // horimetro 2
			payload_id_can_0x200[6] = 0x2A; // horimetro 1
			payload_id_can_0x200[8] = 0x62; // horimetro 0 lsb
		break;

		case 1:
			payload_id_can_0x100[0] = 0x17; // altura_msb
			payload_id_can_0x100[1] = 0x04; // altura_lsb
			payload_id_can_0x100[2] = 0x05; // peso_msb
			payload_id_can_0x100[3] = 0xEA; // peso_lsb
			payload_id_can_0x100[4] = 0x06; // status_flags
			payload_id_can_0x100[5] = 0x00;
			payload_id_can_0x100[6] = 0x00;
			payload_id_can_0x100[7] = 0x00;

			payload_id_can_0x200[0] = 0x62; // tensao
			payload_id_can_0x200[1]	= 0x00;
			payload_id_can_0x200[2] = 0x00;
			payload_id_can_0x200[3] = 0x00;
			payload_id_can_0x200[4] = 0x00; // horimetro 3 msb
			payload_id_can_0x200[5] = 0x00; // horimetro 2
			payload_id_can_0x200[6] = 0x2B; // horimetro 1
			payload_id_can_0x200[8] = 0x63; // horimetro 0 lsb
		break;

		case 2:
			payload_id_can_0x100[0] = 0x18; // altura_msb
			payload_id_can_0x100[1] = 0x05; // altura_lsb
			payload_id_can_0x100[2] = 0x06; // peso_msb
			payload_id_can_0x100[3] = 0xEB; // peso_lsb
			payload_id_can_0x100[4] = 0x05; // status_flags
			payload_id_can_0x100[5] = 0x00;
			payload_id_can_0x100[6] = 0x00;
			payload_id_can_0x100[7] = 0x00;

			payload_id_can_0x200[0] = 0x64; // tensao
			payload_id_can_0x200[1]	= 0x00;
			payload_id_can_0x200[2] = 0x00;
			payload_id_can_0x200[3] = 0x00;
			payload_id_can_0x200[4] = 0x00; // horimetro 3 msb
			payload_id_can_0x200[5] = 0x00; // horimetro 2
			payload_id_can_0x200[6] = 0x2C; // horimetro 1
			payload_id_can_0x200[8] = 0x64; // horimetro 0 lsb
		break;

		case 3:
			payload_id_can_0x100[0] = 0x19; // altura_msb
			payload_id_can_0x100[1] = 0x06; // altura_lsb
			payload_id_can_0x100[2] = 0x07; // peso_msb
			payload_id_can_0x100[3] = 0xEC; // peso_lsb
			payload_id_can_0x100[4] = 0x04; // status_flags
			payload_id_can_0x100[5] = 0x00;
			payload_id_can_0x100[6] = 0x00;
			payload_id_can_0x100[7] = 0x00;

			payload_id_can_0x200[0] = 0x66; // tensao
			payload_id_can_0x200[1]	= 0x00;
			payload_id_can_0x200[2] = 0x00;
			payload_id_can_0x200[3] = 0x00;
			payload_id_can_0x200[4] = 0x00; // horimetro 3 msb
			payload_id_can_0x200[5] = 0x00; // horimetro 2
			payload_id_can_0x200[6] = 0x2D; // horimetro 1
			payload_id_can_0x200[8] = 0x65; // horimetro 0 lsb
		break;
	}
}

/* USER CODE END 1 */
