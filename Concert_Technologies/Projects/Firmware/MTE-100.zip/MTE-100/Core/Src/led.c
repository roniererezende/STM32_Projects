/*
 * led.c
 *
 *  Created on: Oct 23, 2025
 *      Author: Roniere_Rezende
 */

/* INCLUDE */
#include <mte100.h>

/*  FUNCTIONS */
/*
 * @Função    : led_init
 * @Descrição : Inicializa o LED em nível lógico baixo e configura a flag de toggle LED para nível lógico baixo.
 * @Parâmetros: Não há
 */
void led_init(void)
{
	LED_STATUS_LOW();
	mte100.led.toggle  = false;
}

/*
 * @Função    : led_idle_
 * @Descrição : Mantém o LED apagado enquanto aguarda o recebimento dos dados da CAN ou transmissão via MQTT.
 * @Parâmetros: Não há
 */
void led_idle_(void)
{
	LED_STATUS_LOW();
	mte100.led.toggle = false;
}

/*
 * @Função    : led_rx_data_can
 * @Descrição : Realiza o toggle do LED indicando o recepção dos dados via protocolo CAN.
 * @Parâmetros: Não há
 */
void led_rx_data_can(void)
{
	if(mte100.led.toggle == true)
	{
		LED_STATUS_TOGGLE();
		mte100.led.toggle = false;
	}
}

/*
 * @Função    : led_tx_transmit_data_mqtt
 * @Descrição : Realiza o toggle do LED indicando o transmissão dos dados via tópico MQTT.
 * @Parâmetros: Não há
 */
void led_tx_transmit_data_mqtt(void)
{
	if(mte100.led.toggle == true)
	{
		LED_STATUS_TOGGLE();
		mte100.led.toggle = false;
	}

}

/*
 * @Função    : led_handle
 * @Descrição : Manipula o LED de acordo com o seu estado.
 * @Parâmetros: Não há
 */
void led_handle(void)
{
	switch (mte100.led.state)
	{
		case led_initialization:
			led_init();
		break;

		case led_idle:
			led_idle_();
			break;

		case led_receive_data_can:
			led_rx_data_can();
			break;

		case led_transmit_data_mqtt:
			led_tx_transmit_data_mqtt();
			break;
	}
}
