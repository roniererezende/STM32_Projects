/*
 * mqtt.c
 *
 *  Created on: Oct 23, 2025
 *      Author: Roniere_Rezende
 */

/* INCLUDES */
#include <mte100.h>

/* VARIABLES */
mqtt_client_t *client;
ip_addr_t     mqtt_server_ip;

/* FUNCTIONS */

/*
 * @Função    : mqtt_init
 * @Descrição : Define o IP do broker e realiza a conexão do cliente ao tópico MQTT.
 * @Parâmetros: Não há
 */
void mqtt_init(void)
{
	mqtt_set_broker();
	err_t err = mqtt_client_connect(client, &mqtt_server_ip, MQTT_BROKER_PORT, mqtt_connection_cb, 0, NULL);

	if(err != ERR_OK)
	{
		mte100_error_handler();
	}
	else
	{

	}
}

/*
 * @Função    : mqtt_set_broker
 * @Descrição : Configura o IP do broker e cria a instância do cliente MQTT.
 * @Parâmetros: Não há
 */
void mqtt_set_broker(void)
{
	// Configura IP do broker
	ipaddr_aton(MQTT_BROKER_IP, &mqtt_server_ip);

	client = mqtt_client_new();

	if(client == NULL)
	{
		Error_Handler();
	}
}

/*
 * @Função    :  mqtt_publish_data
 * @Descrição : Responsável por montar o JSON e enviá-lo ao broker MQTT.
 * @Parâmetros: Não há
 */
void mqtt_publish_data(void)
{
	mqtt_create_json_protocol();

	err_t result = mqtt_publish(client, MQTT_TOPIC, mte100.mqtt.payload, strlen((char *)mte100.mqtt.payload), 0, 0, NULL, NULL);

	if(result == ERR_OK)
	{
	}
	else
	{
		mte100_error_handler();
	}
}

/*
 * @Função    :  mqtt_connection_cb
 * @Descrição : Chama automaticamente quando o cliente MQTT tanta se conhectar ao broker.
 * @Parâmetros:
 * 		- client: referência ao cliente MQTT ativo
 * 		- arg   : usado para passar contexto extra
 * 		- status: indica o resultado da tentativa de conexão
 *
 */
void mqtt_connection_cb(mqtt_client_t *client, void *arg, mqtt_connection_status_t status)
{
	if(status == MQTT_CONNECT_ACCEPTED)
	{
	}
	else
	{
		mte100_error_handler();
	}
}

/*
 * @Função    : mqtt_create_json_protocol
 * @Descrição : Cria a string de acordo com o protocol JSON.
 * @Parâmetros: Não há
 */
void mqtt_create_json_protocol(void)
{
    char motor_ligado[6]   = {};
    char cesto_nivelado[6] = {};
    char sobrecarga[6]     = {};

    float altura  = mte100.data.altura / 1000;
    uint16_t peso = mte100.data.peso;
    float tensao = (float)mte100.data.tensao;
    uint32_t horimetro = mte100.data.horimetro;


    // Motor ligado
    if(payload_id_can_0x100[4] == true)
    {
         strcpy(motor_ligado,"true");
    }
    else
    {
        strcpy(motor_ligado,"false");
    }

    // Cesto Nivelado
    if(payload_id_can_0x100[4] == true)
    {
         strcpy(cesto_nivelado,"true");
    }
    else
    {
        strcpy(cesto_nivelado,"false");
    }

    // Sobrecarga
    if(payload_id_can_0x100[4] == true)
    {
         strcpy(sobrecarga,"true");
    }
    else
    {
        strcpy(sobrecarga,"false");
    }


    sprintf((char *)mte100.mqtt.payload,
        "{"
        "\"altura_m\":%.1f,"
        "\"peso_kg\":%u,"
        "\"tensao_v\":%.1f,"
        "\"horimetro_h\":%lu,"
        "\"motor_ligado\":%s,"
        "\"cesto_nivelado\":%s,"
        "\"sobrecarga\":%s"
        "}",
        altura, peso, tensao, horimetro, motor_ligado, cesto_nivelado, sobrecarga);
}

/*
 * @Função    : mqtt_transmission
 * @Descrição : Realiza a transmissão dos dados via tópico MQTT.
 * @Parâmetros: Não há
 */
void mqtt_transmission(void)
{
	MX_LWIP_Process();

	if(mte100.mqtt.transmit == true)
	{
		mqtt_publish_data();
		mte100.mqtt.transmit = false;
	}
}
