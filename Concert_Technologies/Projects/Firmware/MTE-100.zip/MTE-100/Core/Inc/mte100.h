/*
 * bsp.h
 *
 *  Created on: Oct 23, 2025
 *      Author: Roniere_Rezende
 */

#ifndef INC_MTE100_H_
#define INC_MTE100_H_

/* INCLUDES */
#include "main.h"
#include "string.h"
#include "lwip.h"
#include "lwip/api.h"
#include "lwip/apps/mqtt.h"
#include "stdbool.h"
#include "stdio.h"
#include "can.h"


#include "stm32f7xx_it.h"

//#include "can.h"
//#include "lwip.h"
#include "gpio.h"

#include "can.h"
#include "led.h"
#include "mqtt.h"

//#include <stdbool.h>


/* STRUCTURES */
typedef enum
{
	mte100_initialization= 0,
	mte100_set_broker_IP,
	mte100_idle,
	mte100_reception_can,
	mte100_transmission_json
}bsp_state_e;

typedef struct
{
	uint16_t altura;
	uint16_t peso;
	uint8_t  status_flags;

	uint8_t  tensao;
	uint32_t horimetro;
}data_s;

typedef struct
{
	bsp_state_e state;

	led_s led;

	data_s data;

	mqtt_s mqtt;
}mte100_s;

/* VARIABLES */
extern mte100_s mte100;

/* SIMULATION DATA */
extern uint16_t altura;
extern uint16_t peso;
extern uint8_t  status_flags;

extern uint8_t  volts;
extern uint8_t  valor;
extern uint32_t horimetro;

extern uint8_t payload_id_can_0x100[8];
extern uint8_t payload_id_can_0x200[8];

extern mqtt_client_t *client;
extern ip_addr_t     mqtt_server_ip;

/* FUNCTION PROTOTYPES */
void mte100_init(void);
void mte100_set_broker(void);
void mte100_idle_(void);
void mte100_main(void);
void mte100_error_handler(void);


#endif /* INC_MTE100_H_ */
