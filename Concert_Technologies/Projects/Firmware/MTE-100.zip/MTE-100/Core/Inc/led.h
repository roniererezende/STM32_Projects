/*
 * led.h
 *
 *  Created on: Oct 23, 2025
 *      Author: Roniere_Rezende
 */

#ifndef INC_LED_H_
#define INC_LED_H_

/* INCLUDES */
#include "mte100.h"

/* DEFINES */
#define LED_STATUS_HIGH()   (HAL_GPIO_WritePin(LED_STATUS_GPIO_Port, LED_STATUS_Pin, GPIO_PIN_SET))
#define LED_STATUS_LOW()    (HAL_GPIO_WritePin(LED_STATUS_GPIO_Port, LED_STATUS_Pin, GPIO_PIN_RESET))
#define LED_STATUS_TOGGLE() (HAL_GPIO_TogglePin(LED_STATUS_GPIO_Port, LED_STATUS_Pin))

/* STRUCTURES */
typedef enum
{
	led_initialization = 0,
	led_idle,
	led_receive_data_can,
	led_transmit_data_mqtt
}led_e;

typedef struct
{
	led_e state;

	bool toggle;
}led_s;

/* FUNCTIONS PROTOTYPE */
void led_init(void);
void led_rx_data_can(void);
void led_tx_transmit_data_mqtt(void);

void led_handle(void);

#endif /* INC_LED_H_ */
